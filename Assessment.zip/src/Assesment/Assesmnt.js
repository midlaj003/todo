import React,{useState} from 'react'
import styled from "styled-components"
import Img1 from "./images/Ellipse 1.png"
import Img2 from "./images/Ellipse -1.png"
import Img3 from "./images/Ellipse -2.png"
import Img4 from "./images/Ellipse -3.png"
import Img5 from "./images/Ellipse -4.png"


export default function Assesmnt() {

    const [bdays,SetBdays]=useState([
        {
            id:1,
            image:Img1,
            name:"Griffin Wooldridge",
            age:"20 years",
        },
        {
            id:2,
            image:Img2,
            name:"Hester Hogan",
            age:"23 years",
        },
        {
            id:3,
            image:Img3,
            name:"Danny Winget",
            age:"25 years",
        },
        {
            id:4,
            image:Img4,
            name:"Joshua Vergara",
            age:"23 years",
        },
        {
            id:5,
            image:Img5,
            name:"Jon Rettinger",
            age:"20 years",
        },
    ])

const renderItems=()=>{
    return bdays.map((birthday)=>(
        <LiItem key={birthday.id}>
            <RightSec>
                <Img src={birthday.image} alt=""></Img>
            </RightSec>
            <LeftSec>
                <H3Name>{birthday.name}</H3Name>
                <SpanAge>{birthday.age}</SpanAge>
            </LeftSec>
        </LiItem>
    ))
}

const clear=()=>{
    SetBdays([]);
};

  return <Container>
            <Heading>5 Birthdys today</Heading>
            <ContentContainer>
                <UlList>
                {renderItems()}
                </UlList>
            </ContentContainer>
            <ClearButton onClick={clear}>clear All</ClearButton>
         </Container>
}





const Container=styled.div`
width:50%;
margin:0 auto;
`;
const Heading=styled.h1`
text-align:center;`;
const ContentContainer=styled.div`
margin-left:20px`;
const UlList=styled.ul``;
const LiItem=styled.li`
display:flex;
align-items:center;
margin-bottom:20px;
`;
const RightSec=styled.div`
margin-right:28px;
width:100px;`;
const Img=styled.img`
display:block;
width:100%`;
const LeftSec=styled.div``;
const H3Name=styled.h3`
margin:0px`;
const SpanAge=styled.span`
color:gray`;
const ClearButton=styled.button`
display:block;
width:65%;
height:40px;
margin:0 auto;
background:#fc038c;
color:#fff;
border:none;
border-radius:4px;
cursor:pointer;
margin-bottom:32px`;

