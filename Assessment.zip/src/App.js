import React from 'react'
import Assesmnt from './Assesment/Assesmnt'

export default function App() {
  return (
    <Assesmnt/>
  )
}
